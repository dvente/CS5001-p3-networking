In addition to the basic requrements we also implemented a logging function. 
	For every request the server responds to a line will be added to the YYYYMMDD.log file (named after the days date)
	The log files are located in a `logs/` directory
